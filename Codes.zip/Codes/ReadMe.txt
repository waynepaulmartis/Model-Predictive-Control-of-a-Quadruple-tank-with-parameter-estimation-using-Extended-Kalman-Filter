Modeling
a,b) - dynamics.mlx

Optimal Control
a, b)  - ocp_tracking_error.mlx
	- ocp_lqr.mlx
c, d) - ocp_time.mlx
e) - ocp_min_time_and_control.mlx

Model Predictive Control

b) - mpc.mlx
c) - mpc_incorrect_para.mlx
d) - mpc_gaussian.mlx